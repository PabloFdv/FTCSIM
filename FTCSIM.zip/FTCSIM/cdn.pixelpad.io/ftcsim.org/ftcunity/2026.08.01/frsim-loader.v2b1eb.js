/**
 * FRSim Loader - Loads FRSim into a container element
 * Handles localhost (Vite dev), WordPress embed, and production (S3) builds
 *
 * SOURCE OF TRUTH — edit this file, then run `npm run build` in FRSim/.
 * Do not edit frsim_build/frsim-loader.v2.js directly; it is generated at build time.
 *
 * Usage:
 *   <div id="frsim-container"></div>
 *   <script src="frsim-loader.v2.js"></script>
 */

(function () {
  'use strict';

  console.log('FRSim Loader Build created at', '2026-09-02T08:58:40.334Z');

  if (window.__frsimLoaderInitialized) {
    return;
  }
  window.__frsimLoaderInitialized = true;

  // Build timestamp will be injected during build process

  // Detect WordPress embed vs pure Vite dev
  const isWordPressEmbed = typeof unityData !== "undefined" &&
    typeof unityData.s3BuildUrl === "string" &&
    unityData.s3BuildUrl !== "";

  // Detect localhost only for non-WordPress Vite dev
  const isLocalhost = !isWordPressEmbed && (
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    window.location.hostname === ""
  );

  // Detect the loader script's location to determine base path
  // Find the script tag that loaded this file
  const currentScript = document.currentScript ||
    (function () {
      const scripts = document.getElementsByTagName('script');
      return scripts[scripts.length - 1];
    })();

  // Get the base path from the loader script's location
  // If script is at https://example.com/path/frsim-loader.v2.js, basePath is /path/
  let basePath = '';
  if (currentScript && currentScript.src) {
    try {
      const scriptUrl = new URL(currentScript.src);
      const scriptPath = scriptUrl.pathname;
      // Remove the filename (frsim-loader.v2.js) to get the directory
      const pathParts = scriptPath.split('/').filter(p => p);
      if (pathParts.length > 0) {
        pathParts.pop(); // Remove the filename
        basePath = '/' + pathParts.join('/') + '/';
      } else {
        basePath = '/';
      }
    } catch (e) {
      console.warn('FRSim Loader: Could not parse script URL, using root path');
      basePath = '/';
    }
  }

  // AWS base URL for file loading
  const AWS_BASE_URL = 'https://s3.us-west-1.amazonaws.com/ftcsim.org/ftcunity';

  // Extract the path after /ftcunity/ from basePath to avoid duplication
  // If basePath is /ftcsim.org/ftcunity/testbuild/, extract just testbuild/
  let pathAfterFtcunity = '';
  if (!isLocalhost && basePath) {
    const ftcunityIndex = basePath.indexOf('https://ftcsim.org/ftcunity/');
    if (ftcunityIndex >= 0) {
      pathAfterFtcunity = basePath.substring(ftcunityIndex + '/ftcunity/'.length);
    } else {
      // If /ftcunity/ not found, use the basePath as-is (might be just /testbuild/)
      pathAfterFtcunity = basePath.startsWith('/') ? basePath.substring(1) : basePath;
    }
  }

  // Determine effective base path for Unity assets
  let effectiveBasePath = "";
  if (isWordPressEmbed && typeof unityData.currentFtcsimVersion === "string" && unityData.currentFtcsimVersion !== "") {
    // In WordPress, prefer the version WordPress selected (e.g. "testbuild")
    effectiveBasePath = unityData.currentFtcsimVersion;
  } else if (isLocalhost) {
    // Vite dev server serves from root
    effectiveBasePath = "";
  } else {
    // S3 builds infer version from the loader script path
    effectiveBasePath = (pathAfterFtcunity || "");
  }

  // Ensure base path, when present, always ends with a single trailing slash
  const normalizedBasePath = effectiveBasePath === ""
    ? ""
    : (effectiveBasePath.endsWith("/") ? effectiveBasePath : effectiveBasePath + "/");

  // Configuration
  const config = {
    // Base path relative to loader script location (empty for localhost)
    basePath: normalizedBasePath,
    // Template file path (relative to loader script, or root for localhost)
    templatePath: isLocalhost ? '/frsim-template.html' : (normalizedBasePath + 'frsim-template.html'),
    // Container selector
    containerSelector: '#frsim-container'
  };

  // Container will be found in init() after DOM is ready
  let container = null;

  // Helper function to construct absolute URLs using AWS base URL
  // This ensures fetch() and other APIs use AWS URLs instead of relative paths
  function getResourceUrl(relativePath) {
    if (isLocalhost) {
      return relativePath;
    }
    // Always use AWS base URL in production
    // Ensure AWS_BASE_URL doesn't end with / and relativePath starts with /
    const awsBase = AWS_BASE_URL.endsWith('/') ? AWS_BASE_URL.slice(0, -1) : AWS_BASE_URL;
    const path = relativePath.startsWith('/') ? relativePath : '/' + relativePath;
    return awsBase + path;
  }

  function addCacheBust(url) {
    if (isLocalhost) {
      return url;
    }
    const buildTime = '2026-09-02T08:58:40.334Z';
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}${buildTime}`;
  }

  // Set base URL for relative paths (only for production, and only if no base tag exists)
  if (!isLocalhost && !document.querySelector('base')) {
    const baseTag = document.createElement('base');
    // Always use AWS base URL + path after /ftcunity/ in production
    const awsBase = AWS_BASE_URL.endsWith('/') ? AWS_BASE_URL.slice(0, -1) : AWS_BASE_URL;
    const path = config.basePath.startsWith('/') ? config.basePath : '/' + config.basePath;
    baseTag.href = awsBase + path;
    document.head.insertBefore(baseTag, document.head.firstChild);
  }

  // Expose the resolved asset base so in-app fetches can avoid host page base tags.
  if (!isLocalhost) {
    const awsBase = AWS_BASE_URL.endsWith('/') ? AWS_BASE_URL.slice(0, -1) : AWS_BASE_URL;
    const path = config.basePath.startsWith('/') ? config.basePath : '/' + config.basePath;
    window.__frsimAssetBase = awsBase + path;
  }

  // Helper: Load CSS (gracefully handles errors)
  function loadCSS(url) {
    return new Promise((resolve, reject) => {
      // Check if already loaded
      const existing = document.querySelector(`link[href="${url}"]`);
      if (existing) {
        resolve();
        return;
      }

      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = url;
      link.onload = () => {
        resolve();
      };
      link.onerror = (error) => {
        console.warn('CSS failed to load:', url, error);
        // Still resolve to prevent breaking initialization
        // The page will still work, just without this CSS file
        resolve();
      };
      document.head.appendChild(link);
    });
  }

  // Helper: Load Script
  function loadScript(url, options = {}) {
    return new Promise((resolve, reject) => {
      const cacheBustedUrl = addCacheBust(url);
      // Check if already loaded
      const existing = document.querySelector(`script[src="${cacheBustedUrl}"]`);
      if (existing) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = cacheBustedUrl;
      script.type = options.type || 'text/javascript';
      if (options.crossOrigin) {
        script.crossOrigin = options.crossOrigin;
      }
      script.async = options.async !== false;
      script.onload = resolve;
      script.onerror = reject;
      (options.appendTo || document.head).appendChild(script);
    });
  }

  function applyOverlayLayout(overlay, isFullscreen) {
    overlay.style.position = isFullscreen ? 'fixed' : 'absolute';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = isFullscreen ? '100vw' : '100%';
    overlay.style.height = isFullscreen ? '100vh' : '100%';
    overlay.style.zIndex = '999999';
  }

  // Load HTML template
  function loadTemplate() {
    const templateUrl = (isWordPressEmbed &&
      typeof unityData.s3TemplateUrl === "string" &&
      unityData.s3TemplateUrl !== "")
      ? unityData.s3TemplateUrl
      : getResourceUrl(config.templatePath);
    return fetch(templateUrl, { cache: "no-store" })
      .then(response => {
        if (!response.ok) {
          throw new Error(`Failed to load template: ${response.statusText}`);
        }
        return response.text();
      })
      .then(html => {
        const existingOverlay = document.getElementById('frsim-loading-overlay');
        if (existingOverlay && existingOverlay.parentNode === container) {
          existingOverlay.remove();
        }

        container.innerHTML = html;
        container.style.cssText = 'width: 100%; height: 100%; position: relative; overflow: hidden;';
        // Add frsim-app-root class to app-root for embedded mode styling
        const appRoot = container.querySelector('#app-root');
        if (appRoot) {
          appRoot.classList.add('frsim-app-root');
        }

        if (existingOverlay) {
          container.appendChild(existingOverlay);
          placeLoadingOverlay(existingOverlay);
        }
      });
  }

  // Load fonts
  function loadFonts() {
    if (document.querySelector('link[href*="fonts.googleapis.com"]')) {
      return; // Already loaded
    }

    const link1 = document.createElement('link');
    link1.rel = 'preconnect';
    link1.href = 'https://fonts.googleapis.com/';
    document.head.appendChild(link1);

    const link2 = document.createElement('link');
    link2.rel = 'preconnect';
    link2.href = 'https://fonts.gstatic.com/';
    link2.crossOrigin = 'anonymous';
    document.head.appendChild(link2);

    const fontLink = document.createElement('link');
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap';
    fontLink.rel = 'stylesheet';
    document.head.appendChild(fontLink);
  }

  // Load Blockly
  function loadBlockly() {
    // Check if Blockly is already loaded and initialized
    if (window.Blockly && window.Blockly.Blocks) {
      return Promise.resolve();
    }

    // Check if Blockly scripts are already in the DOM (loading)
    const blocklyScripts = [
      'https://cdn.jsdelivr.net/npm/blockly@12.3.1/blockly.min.js'
    ];

    const scriptsInDOM = blocklyScripts.map(url =>
      document.querySelector(`script[src="${url}"]`) !== null
    );

    // If all scripts are already in DOM, wait for them to load
    if (scriptsInDOM.every(Boolean)) {
      return new Promise((resolve) => {
        // Wait for Blockly to be available
        const checkBlockly = setInterval(() => {
          if (window.Blockly && window.Blockly.Blocks) {
            clearInterval(checkBlockly);
            resolve();
          }
        }, 50);

        // Timeout after 5 seconds
        setTimeout(() => {
          clearInterval(checkBlockly);
          resolve(); // Resolve anyway
        }, 5000);
      });
    }

    // Load Blockly scripts sequentially to ensure proper dependency order.
    return blocklyScripts
      .reduce((chain, src) => chain.then(() => loadScript(src, { async: false })), Promise.resolve())
      .then(() => {
        // Wait for Blockly to be fully initialized
        return new Promise((resolve) => {
          const checkBlockly = setInterval(() => {
            if (window.Blockly) {
              clearInterval(checkBlockly);
              resolve();
            }
          }, 10);

          // Timeout after 2 seconds
          setTimeout(() => {
            clearInterval(checkBlockly);
            if (!window.Blockly) {
              console.warn('FRSim%20Loader_%20Blockly%20not%20available%20after%20loading%20blockly.min.html');
            }
            resolve();
          }, 2000);
        });
      });
  }

  // Load Monaco Editor
  function loadMonaco() {
    return new Promise((resolve) => {
      let restorePatchedDefine = null;
      // Check if Monaco is already loaded
      if (window.monaco) {
        resolve();
        return;
      }

      // Check if Monaco loader is already set up (to avoid AMD conflicts)
      if (window.require && window.require.config) {
        // Save existing require if it exists
        const existingRequire = window.require;

        loadCSS('../../../../cdn.jsdelivr.net/npm/monaco-editor%400.49.0/min/vs/editor/editor.main.css')
          .then(() => {
            // Configure Monaco paths using existing require
            existingRequire.config({
              paths: {
                vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.49.0/min/vs',
                ...existingRequire.require.s.contexts._.config.paths
              }
            });

            window.MonacoEnvironment = {
              getWorkerUrl: function (workerId, label) {
                const workerBase = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.49.0/min';
                const workerMain = `${workerBase}/vs/base/worker/workerMain.js`;
                const proxy = `self.MonacoEnvironment={baseUrl:'${workerBase}/'};importScripts('${workerMain}');`;
                return `data:text/javascript;charset=utf-8,${encodeURIComponent(proxy)}`;
              }
            };

            // Patch AMD loader to allow multiple anonymous define calls
            const originalEnqueueDefineAnonymousModule = existingRequire.s && existingRequire.s.enqueueDefineAnonymousModule;
            if (existingRequire.s && originalEnqueueDefineAnonymousModule) {
              existingRequire.s.enqueueDefineAnonymousModule = function (module) {
                try {
                  return originalEnqueueDefineAnonymousModule.call(this, module);
                } catch (e) {
                  if (e.message && e.message.includes('Can only have one anonymous define')) {
                    console.warn('Monaco AMD: Ignoring duplicate anonymous define (likely from chevrotain-java)');
                    return;
                  }
                  throw e;
                }
              };
            }

            // Try to load Monaco using existing require
            existingRequire(['vs/editor/editor.main'], function () {
              if (typeof monaco !== 'undefined') {
                window.monaco = monaco;
              } else if (typeof self !== 'undefined' && self.monaco) {
                window.monaco = self.monaco;
              }
              window.monacoLoaded = true;
              resolve();
            });
          })
          .catch((error) => {
            console.warn('Monaco Editor failed to load:', error);
            resolve(); // Resolve anyway - Monaco is optional for some features
          });
        return;
      }

      // Normal Monaco loading (no existing AMD loader)
      loadCSS('../../../../cdn.jsdelivr.net/npm/monaco-editor%400.49.0/min/vs/editor/editor.main.css')
        .then(() => {
          return loadScript('../../../../cdn.jsdelivr.net/npm/monaco-editor%400.49.0/min/vs/loader.min.js');
        })
        .then(() => {
          const monacoRequire = window.require;
          monacoRequire.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.49.0/min/vs' } });

          window.MonacoEnvironment = {
            getWorkerUrl: function (workerId, label) {
              const workerBase = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.49.0/min';
              const workerMain = `${workerBase}/vs/base/worker/workerMain.js`;
              const proxy = `self.MonacoEnvironment={baseUrl:'${workerBase}/'};importScripts('${workerMain}');`;
              return `data:text/javascript;charset=utf-8,${encodeURIComponent(proxy)}`;
            }
          };

          // Patch AMD loader BEFORE loading Monaco to allow multiple anonymous define calls
          // This prevents conflicts with chevrotain-java and other modules
          if (monacoRequire.s && monacoRequire.s.enqueueDefineAnonymousModule) {
            const originalEnqueueDefineAnonymousModule = monacoRequire.s.enqueueDefineAnonymousModule;
            monacoRequire.s.enqueueDefineAnonymousModule = function (module) {
              try {
                return originalEnqueueDefineAnonymousModule.call(this, module);
              } catch (e) {
                if (e && e.message && e.message.includes('Can only have one anonymous define')) {
                  // Silently ignore duplicate anonymous defines
                  console.warn('Monaco AMD: Ignoring duplicate anonymous define (likely from chevrotain-java)');
                  return;
                }
                throw e;
              }
            };
          }

          // Also patch the global define function to allow multiple anonymous defines
          // This prevents conflicts with chevrotain-java and Unity framework
          if (typeof window.define === 'function' && window.define.amd) {
            const originalDefine = window.define;
            const anonymousModules = new Map();
            let anonymousCounter = 0;

            window.define = function () {
              // If this is an anonymous define (no module name as first arg)
              if (arguments.length > 0 && typeof arguments[0] !== 'string') {
                // Check if we've seen this exact module before by comparing the factory function
                const factory = arguments[0];
                let found = false;
                for (const [id, storedFactory] of anonymousModules.entries()) {
                  if (storedFactory === factory) {
                    // This is a duplicate, just return without error
                    console.warn('Monaco AMD: Ignoring duplicate anonymous define (already registered as ' + id + ')');
                    return;
                  }
                }
                // New anonymous module - register it with a unique ID
                anonymousCounter++;
                const uniqueId = '__anonymous_' + anonymousCounter;
                anonymousModules.set(uniqueId, factory);
                // Register with the unique ID
                return originalDefine.call(this, uniqueId, factory, arguments[1]);
              }
              // Named module - proceed normally
              return originalDefine.apply(this, arguments);
            };
            // Copy properties from original define
            Object.setPrototypeOf(window.define, originalDefine);
            Object.assign(window.define, originalDefine);
	            restorePatchedDefine = () => {
	              // Restore original AMD define once Monaco has initialized.
	              if (window.define !== originalDefine) {
	                window.define = originalDefine;
	              }
	              restorePatchedDefine = null;
	            };
          }

          monacoRequire(['vs/editor/editor.main'], function () {
            if (typeof monaco !== 'undefined') {
              window.monaco = monaco;
            } else if (typeof self !== 'undefined' && self.monaco) {
              window.monaco = self.monaco;
            }
            window.monacoLoaded = true;
            if (typeof restorePatchedDefine === 'function') {
              restorePatchedDefine();
            }
            resolve();
          }, function () {
            if (typeof restorePatchedDefine === 'function') {
              restorePatchedDefine();
            }
            resolve();
          });
        })
        .catch((error) => {
          console.warn('Monaco Editor failed to load:', error);
          if (typeof restorePatchedDefine === 'function') {
            restorePatchedDefine();
          }
          resolve(); // Resolve anyway - Monaco is optional for some features
        });
    });
  }

	  // Python runtime bootstrapping is handled by Simulation.ts (Skulpt iframe runtime).

  // Setup Unity loading
  function setupUnity() {

    const unityDataUrl = isLocalhost
      ? "/frsim_unity_local/UnityData.js"
      : getResourceUrl(config.basePath + "frsim_unity/UnityData.js");

    // Use config.basePath for Unity build paths (relative to loader script location)
    // For localhost, use root paths; for production, use detected basePath
    const buildUrl = isLocalhost
      ? "/frsim_unity_local/Build"
      : (config.basePath + "frsim_unity/Build");
    const loaderUrl = isLocalhost
      ? buildUrl + "/frsim_unity_local.loader.js"
      : getResourceUrl(buildUrl + "/frsim_unity.loader.js");

    const unityContainer = document.querySelector("#unity-container");
    const canvas = document.querySelector("#unity-canvas");
    const loadingBar = document.querySelector("#unity-loading-bar");
    const progressBarFull = document.querySelector("#unity-progress-bar-full");
    const warningBanner = document.querySelector("#unity-warning");

    if (!canvas || !unityContainer) {
      console.warn('Unity container elements not found');
      return { loadUnity: () => { }, resizeUnity: () => { } };
    }

    function unityShowBanner(msg, type, clickable) {
      if (!warningBanner) return;

      function updateBannerVisibility() {
        warningBanner.style.display = warningBanner.children.length ? "block" : "none";
      }
      const div = document.createElement("div");
      div.innerHTML = msg;
      warningBanner.appendChild(div);
      if (type) div.className = type;
      if (clickable) {
        div.style.cursor = "pointer";
        div.addEventListener("click", () => {
          warningBanner.removeChild(div);
          updateBannerVisibility();
        });
      } else {
        if (type == "error") {
          div.addEventListener("click", () => {
            warningBanner.removeChild(div);
            updateBannerVisibility();
          });
        } else {
          setTimeout(() => {
            if (warningBanner.contains(div)) {
              warningBanner.removeChild(div);
              updateBannerVisibility();
            }
          }, 5000);
        }
      }
      updateBannerVisibility();
    }

    function getUnityConfig() {
      return {
        arguments: [],
        dataUrl: isLocalhost
          ? buildUrl + "/frsim_unity_local.data"
          : getResourceUrl(buildUrl + "/frsim_unity.data.br?" + getUnityVersion()),
        frameworkUrl: isLocalhost
          ? buildUrl + "/frsim_unity_local.framework.js"
          : getResourceUrl(buildUrl + "/frsim_unity.framework.js.br?" + getUnityVersion()),
        codeUrl: isLocalhost
          ? buildUrl + "/frsim_unity_local.wasm"
          : getResourceUrl(buildUrl + "/frsim_unity.wasm.br?" + getUnityVersion()),
        streamingAssetsUrl: isLocalhost
          ? "/frsim_unity_local/StreamingAssets"
          : getResourceUrl(config.basePath + "frsim_unity/StreamingAssets"),
        companyName: "FIRST Robotics Canada",
        productName: "FIRST Sim",
        productVersion: getUnityVersion(),
        showBanner: unityShowBanner,
      };
    }

    function startUnityLoad() {
      const script = document.createElement('script');
      script.src = loaderUrl;
      script.onload = () => {
        setTimeout(() => {
          if (typeof createUnityInstance === 'undefined') {
            console.error("createUnityInstance not available after loading script");
            hideLoadingOverlay();
            return;
          }

          const unityConfig = getUnityConfig();
          createUnityInstance(canvas, unityConfig, (progress) => {
            updateLoadingProgress(progress);
            if (progressBarFull) {
              progressBarFull.style.width = 100 * progress + "%";
            }
          }).then((unityInstance) => {
            if (typeof UnityCaller !== 'undefined' && UnityCaller.initCallerFunctions) {
              UnityCaller.initCallerFunctions(unityInstance);
            }

            initializeQuestSystemListener();

            if (loadingBar) {
              loadingBar.style.display = "none";
            }
            hideLoadingOverlay();
            setupFocus();
          }).catch((message) => {
            console.error("Unity failed to load:", message);
            hideLoadingOverlay();
          });
        }, 100);
      };
      script.onerror = () => {
        console.error("Failed to load Unity loader script from:", loaderUrl);
        hideLoadingOverlay();
      };
      document.body.appendChild(script);
    }

    function loadUnity() {
      const unityDataScript = document.createElement('script');
      unityDataScript.src = unityDataUrl;
      unityDataScript.onload = () => {
        startUnityLoad();
      };
      unityDataScript.onerror = () => {
        console.error("FRSim Loader: Failed to load UnityData.js from:", unityDataUrl);
        hideLoadingOverlay();
      };
      document.body.appendChild(unityDataScript);
    }

    function initializeQuestSystemListener() {
      document.addEventListener("questActivated", function (e) {
        UnityCaller.OnQuestUpdate(JSON.stringify(e.detail));
      });

      //This is intended to run in case a Quest would be active before Unity was activated. Maybe not needed
      if (workshop?.tutorial?.getCurrentQuest) {
        let quest = workshop.tutorial.getCurrentQuest();
        if (quest) {
          UnityCaller.OnQuestUpdate(JSON.stringify(quest));
        }
      }
    }

    function setupFocus() {
      const canvas = document.querySelector("#unity-canvas");
      if (!canvas) return;
      canvas.removeAttribute("tabindex");
      canvas.addEventListener("mousedown", () => {
        canvas.setAttribute("tabindex", "1");
        canvas.focus();
      });
      document.addEventListener("mousedown", (e) => {
        if (!canvas.contains(e.target)) {
          canvas.blur();
          canvas.removeAttribute("tabindex");
        }
      });
    }

    function resizeUnity() {
      const unityWrapper = document.getElementById("unity-wrapper");
      const idePanel = document.getElementById("ide-panel");
      if (!unityWrapper) return;

      // Check if we're in embedded mode (has frsim-app-root parent)
      const appRoot = unityWrapper.closest('.frsim-app-root');
      const isEmbedded = !!appRoot;

      const isIDEVisible = idePanel && !idePanel.classList.contains('hidden');

      // Use 100% height in embedded mode to respect parent container, 100vh otherwise
      const heightValue = isEmbedded ? "100%" : "100vh";

      if (isIDEVisible) {
        // IDE is visible - Panel is 50%, button at 50%, Unity starts at 50%
        unityWrapper.style.width = "50%";
        unityWrapper.style.height = heightValue;
        unityWrapper.style.marginLeft = "50%";
      } else {
        // IDE is hidden - Unity takes up full window
        unityWrapper.style.width = "100%";
        unityWrapper.style.height = heightValue;
        unityWrapper.style.marginLeft = "0";
      }
    }

    window.resizeUnity = resizeUnity;
    window.addEventListener("resize", resizeUnity);

    return { loadUnity, resizeUnity };
  }

  // Fun loading phrases
  const loadingPhrasesOriginal = [
    "Grabbing some bolts...",
    "Calibrating sensors...",
    "Teaching the robot to dance...",
    "Installing the collaborative spirit...",
    "Wiring up the brain...",
    "Polishing the chassis...",
    "Loading robot swagger...",
    "Tightening all the screws...",
    "Programming the victory dance...",
    "Charging the batteries...",
    "Testing the motors...",
    "Uploading robot wisdom...",
    "Assembling the dream team...",
    "Calibrating the awesomeness...",
    "Spinning up the wheels...",
    "Warming up the servos...",
    "Almost there, hang tight..."
  ];

  // Shuffle the phrases array once at startup
  function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  const loadingPhrases = shuffleArray(loadingPhrasesOriginal);

  let currentPhraseIndex = 0;
  let phraseInterval = null;

  // Start cycling through phrases every 2 seconds
  function startPhraseCycling() {
    const loadingText = document.querySelector('#frsim-loading-text');
    if (!loadingText) return;

    // Clear any existing interval
    if (phraseInterval) {
      clearInterval(phraseInterval);
    }

    // Set initial phrase
    currentPhraseIndex = 0;
    loadingText.textContent = loadingPhrases[0];

    // Change phrase every 2 seconds, cycling through sequentially
    phraseInterval = setInterval(() => {
      currentPhraseIndex = (currentPhraseIndex + 1) % loadingPhrases.length;
      loadingText.textContent = loadingPhrases[currentPhraseIndex];
    }, 2000);
  }

  // Stop cycling phrases
  function stopPhraseCycling() {
    if (phraseInterval) {
      clearInterval(phraseInterval);
      phraseInterval = null;
    }
    const loadingText = document.querySelector('#frsim-loading-text');
    if (loadingText) {
      loadingText.textContent = "Ready to roll!";
    }
  }

  // Create and show loading overlay
  function showLoadingOverlay() {
    // Check if overlay already exists (from template)
    let overlay = document.getElementById('frsim-loading-overlay');
    if (!overlay) {
      // Create overlay if it doesn't exist yet (before template loads)
      overlay = document.createElement('div');
      overlay.id = 'frsim-loading-overlay';

      const content = document.createElement('div');
      content.id = 'frsim-loading-content';

      // Main loading text (will show funny phrases)
      const loadingText = document.createElement('div');
      loadingText.id = 'frsim-loading-text';
      loadingText.textContent = loadingPhrases[0] || 'Loading Simulator...';

      // Progress bar container
      const progressBarContainer = document.createElement('div');
      progressBarContainer.id = 'frsim-progress-bar-container';

      // Progress bar fill
      const progressBarFull = document.createElement('div');
      progressBarFull.id = 'unity-progress-bar-full';

      // Unity version text (will show Unity version)
      const loadingFileName = document.createElement('div');
      loadingFileName.id = 'frsim-loading-filename';
      loadingFileName.textContent = '';

      progressBarContainer.appendChild(progressBarFull);
      content.appendChild(loadingText);
      content.appendChild(progressBarContainer);
      content.appendChild(loadingFileName);
      overlay.appendChild(content);

    }
    placeLoadingOverlay(overlay);
    overlay.classList.remove('hidden');
    overlay.style.setProperty('display', 'flex', 'important');
    // Start cycling phrases when overlay is shown
    startPhraseCycling();
  }

  function placeLoadingOverlay(overlay) {
    const host = container || document.querySelector(config.containerSelector);
    if (host) {
      if (overlay.parentNode !== host) {
        host.appendChild(overlay);
      }
      overlay.classList.remove('frsim-loading-overlay--fullscreen');
      applyOverlayLayout(overlay, false);
      return;
    }

    // Fallback to fullscreen until the container is available
    const body = document.body || document.documentElement;
    if (body && overlay.parentNode !== body) {
      body.appendChild(overlay);
    }
    overlay.classList.add('frsim-loading-overlay--fullscreen');
    applyOverlayLayout(overlay, true);
  }

  // Hide full-screen loading overlay
  function hideLoadingOverlay() {
    stopPhraseCycling();
    const overlay = document.getElementById('frsim-loading-overlay');
    if (overlay) {
      overlay.style.setProperty('display', 'none', 'important');
      // Also add a class to ensure it stays hidden
      overlay.classList.add('hidden');
    }
  }

  // Update loading progress
  function updateLoadingProgress(progress) {
    const progressBarFull = document.querySelector('#frsim-loading-overlay #unity-progress-bar-full');
    if (progressBarFull) {
      const widthPercent = Math.max(0, Math.min(100, 100 * progress));
      progressBarFull.style.width = widthPercent + '%';
    }

    // Update Unity version text
    const loadingFileName = document.querySelector('#frsim-loading-filename');
    if (loadingFileName) {
      if (getUnityVersion !== undefined) {
        loadingFileName.textContent = getUnityVersion();
      }
    }
  }

  // Main initialization
  async function init() {
    try {
      // Show loading overlay immediately, even before checking for container
      showLoadingOverlay();

      // Find the container (must be done after DOM is ready)
      container = document.querySelector(config.containerSelector);
      if (!container) {
        console.error('FRSim container not found. Looking for:', config.containerSelector);
        // Still show overlay even if container not found, so user sees something
        return;
      }

      // Move the overlay into the container so it stays within the embed
      const overlay = document.getElementById('frsim-loading-overlay');
      if (overlay) {
        placeLoadingOverlay(overlay);
      }


      // Step 1: Add inline style to hide content until CSS is loaded
      const hideStyle = document.createElement('style');
      hideStyle.id = 'frsim-hide-until-css';
      hideStyle.textContent = `
        #app-root { visibility: hidden !important; }
        #app-root.frsim-css-loaded { visibility: visible !important; }
      `;
      document.head.appendChild(hideStyle);

      // Step 2: Load fonts
      loadFonts();

      // Step 3: Load CSS from appropriate source (BEFORE template)
      if (isLocalhost) {
        // In localhost, CSS is served by Vite dev server
        await loadCSS('../../../style.html').catch(() => console.warn('style.css not found'));
        await loadCSS('../../../ide/ide.html').catch(() => console.warn('ide.css not found'));
      } else {
        // In production, load CSS from manifest
        try {
          const manifestUrl = addCacheBust(getResourceUrl(config.basePath + 'assets-manifest.json'));
          const manifestResponse = await fetch(manifestUrl);
          if (manifestResponse.ok) {
            const manifest = await manifestResponse.json();
            if (manifest.css) {
              const cssPath = config.basePath + 'assets/' + manifest.css;
              const cssUrl = addCacheBust(getResourceUrl(cssPath));
              await loadCSS(cssUrl).catch((err) => {
                console.warn('Failed to load CSS from manifest:', cssUrl, err);
              });
            } else {
              console.warn('FRSim Loader: Manifest does not contain CSS filename');
            }
          } else {
            console.warn('FRSim Loader: Could not load manifest for CSS:', manifestResponse.status);
          }
        } catch (manifestError) {
          console.warn('FRSim Loader: Failed to load manifest for CSS:', manifestError);
        }
      }

      // Step 4: Load HTML template (after CSS is loaded)
      await loadTemplate();

      // Step 5: Mark CSS as loaded to show content
      const appRoot = container.querySelector('#app-root');
      if (appRoot) {
        appRoot.classList.add('frsim-css-loaded');
      }

      // Step 6: Load Blockly
      await loadBlockly();

      // Step 7: Load Monaco (wait for it to be fully ready)
      await loadMonaco();

      // Step 7: Wait a bit for Monaco to fully initialize before loading app.js
      // This helps avoid AMD conflicts with other modules
      await new Promise(resolve => setTimeout(resolve, 200));
      // Step 8: Setup Unity
      const unity = setupUnity();

      // Step 9: Ensure template elements exist before loading app.js
      // Wait for template elements to be in the DOM
      let retries = 0;
      while (retries < 10 && !document.getElementById('ide-panel')) {
        await new Promise(resolve => setTimeout(resolve, 100));
        retries++;
      }

      if (!document.getElementById('ide-panel')) {
        console.warn('FRSim Loader: Template elements not found, app.js may fail to initialize IDE');
      }

      // Step 10: Load main application script
      if (isLocalhost) {
        // In localhost, use Vite dev server
        // Temporarily override AMD loader so chevrotain-java uses Vite's module system
        const originalDefine = window.define;
        const originalRequire = window.require;
        let defineOverride = null;
        let requireOverride = null;

        if (window.define && window.define.amd) {
          // Temporarily override to hide AMD from chevrotain-java
          defineOverride = function () {
            // If this looks like chevrotain-java trying to use AMD, ignore it
            const stack = new Error().stack || '';
            if (stack.includes('chevrotain') || stack.includes('regexp-to-ast')) {
              // Let it fall through to Vite's module system
              return;
            }
            // Otherwise, use original define
            return originalDefine.apply(this, arguments);
          };
          // Copy properties
          Object.setPrototypeOf(defineOverride, originalDefine);
          Object.assign(defineOverride, originalDefine);
          // Temporarily remove amd flag
          defineOverride.amd = false;
          window.define = defineOverride;
        }

        // Load as module - Vite will handle the imports
        try {
          await loadScript('../../../app.html', { type: 'module' });
        } catch (error) {
          console.warn('FRSim Loader: Error loading app.js, but continuing:', error);
        }

        // Restore AMD loader after a short delay
        await new Promise(resolve => setTimeout(resolve, 200));
        if (originalDefine) {
          window.define = originalDefine;
        }
        if (originalRequire) {
          window.require = originalRequire;
        }

        // Wait for app.js to execute and initialize IDE
        // Check periodically if IDE is initialized
        let ideCheckRetries = 0;
        while (ideCheckRetries < 20 && !window.frsimIDE) {
          await new Promise(resolve => setTimeout(resolve, 100));
          ideCheckRetries++;
        }

        if (window.frsimIDE) {
        } else {
          console.warn('FRSim Loader: IDE not initialized after loading app.js, trying direct initialization...');
          // Fallback: Try to initialize IDE directly using dynamic import
          try {
            // Import IDE module directly
            const { IDE } = await import('https://cdn.pixelpad.io/ide/ide.ts');
            const ide = new IDE();
            await ide.initialize();
            window.frsimIDE = ide;
          } catch (fallbackError) {
            console.error('FRSim Loader: Fallback IDE initialization failed:', fallbackError);
          }
        }
      } else {
        // In production, load from manifest file

        try {
          const manifestUrl = addCacheBust(getResourceUrl(config.basePath + 'assets-manifest.json'));
          const manifestResponse = await fetch(manifestUrl);
          if (!manifestResponse.ok) {
            throw new Error(`Failed to load manifest: ${manifestResponse.status}`);
          }

          const manifest = await manifestResponse.json();

          if (!manifest.main) {
            throw new Error('Manifest does not contain main script filename');
          }

          // Load main script
          const mainPath = config.basePath + 'assets/' + manifest.main;
          const mainUrl = getResourceUrl(mainPath);
          await loadScript(mainUrl, { type: 'module' });

          // Preload vendor if available
          if (manifest.vendor) {
            const vendorPath = config.basePath + 'assets/' + manifest.vendor;
            const vendorUrl = addCacheBust(getResourceUrl(vendorPath));
            const vendorPreload = document.createElement('link');
            vendorPreload.rel = 'modulepreload';
            vendorPreload.crossOrigin = 'anonymous';
            vendorPreload.href = vendorUrl;
            document.head.appendChild(vendorPreload);
          }
        } catch (manifestError) {
          console.error('FRSim Loader: Failed to load manifest:', manifestError);
          throw new Error(
            'FRSim Loader: Failed to load assets-manifest.json. ' +
            'Please ensure the manifest file exists in the assets directory.'
          );
        }

        // Wait for initialization
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      // Step 9: Python runtime bootstraps in Simulation.ts.

      // Step 10: Initialize Unity after a short delay
      setTimeout(() => {
        unity.resizeUnity();
        unity.loadUnity();
      }, 500);

    } catch (error) {
      console.error('FRSim Loader: Error during initialization:', error);
      hideLoadingOverlay();
      if (container) {
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: red;">Failed to load FRSim. Please check the console for errors.</div>';
      }
    }
  }

  // Show loading overlay immediately, even before DOM is ready
  // This ensures users see something right away
  try {
    if (document.body) {
      showLoadingOverlay();
    } else if (document.readyState === 'loading') {
      // If body doesn't exist yet, wait for it
      document.addEventListener('DOMContentLoaded', () => {
        try {
          showLoadingOverlay();
        } catch (e) {
          console.error('FRSim Loader: Error showing overlay on DOMContentLoaded:', e);
        }
      });
    } else {
      // DOM is already ready but body might not exist (unlikely)
      showLoadingOverlay();
    }
  } catch (e) {
    console.error('FRSim Loader: Error showing overlay early:', e);
    // Continue anyway - overlay will be shown in init()
  }

  // Start loading when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
